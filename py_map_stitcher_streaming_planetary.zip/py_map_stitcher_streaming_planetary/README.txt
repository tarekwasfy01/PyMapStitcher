Py Map Stitcher - Streaming/Planetary Engine

Start on Windows:
1. Run START_WINDOWS.bat
or:
   python py_map_stitcher.py

Install for Python 3.8 / Anaconda:
   python -m pip install requests pillow numpy==1.22.4 tifffile==2023.7.10

Major changes in this version:
- No global tile range/list is created in memory.
- No full-area pre-scan for existing tiles before downloading.
- Tiles are processed by a spatial chunk scheduler.
- Default chunk size: 64 x 64 tiles.
- Download is streamed with a bounded number of in-flight futures.
- SQLite resume database is written into the cache folder.
- Finished/error tile states are stored in SQLite.
- Direct BigTIFF memmap writing is used when the output is realistically sized.
- If the requested BigTIFF would be too large, the app continues as tile/cache + SQLite streaming mode.
- Optional individual TIFF tile saving is available, but disabled by default because millions of small TIFF files are very slow on Windows.
- Existing raw tile files are still skipped/reused.

Important:
Downloading the whole Earth at high zoom can mean billions of tiles and many terabytes/petabytes of data.
Use only tile servers where this kind of downloading is allowed.
