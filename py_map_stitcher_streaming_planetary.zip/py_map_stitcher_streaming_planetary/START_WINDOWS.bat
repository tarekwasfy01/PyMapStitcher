@echo off
python py_map_stitcher.py
pause
