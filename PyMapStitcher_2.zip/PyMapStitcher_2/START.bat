\
@echo off
setlocal
cd /d "%~dp0"
py -3 "%~dp0py_map_stitcher_OLD_DOWNLOAD_georef_no_stop.py"
if errorlevel 1 pause
